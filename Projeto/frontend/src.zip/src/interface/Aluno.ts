export interface Aluno {
  aluno_id: number;
  nome_aluno: string;
  ra_aluno: string;
  data_nascimento: string;
  password: string;
  cursos: string[];
}