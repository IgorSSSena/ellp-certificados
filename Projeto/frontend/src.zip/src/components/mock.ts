export const mockCursos = [
  { id: 1, titulo: "Programação Web" },
  { id: 2, titulo: "Banco de Dados" },
  { id: 3, titulo: "Engenharia de Software" },
];

export const mockAlunos = [
  { id: 1, nome: "Igor Sena", email: "igor@email.com" },
  { id: 2, nome: "Ana Costa", email: "ana@email.com" },
  { id: 3, nome: "Lucas Lima", email: "lucas@email.com" },
];
