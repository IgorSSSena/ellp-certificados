import React from "react";
import CourseCard from "./CourseCard";
import "../styles/course_list.css";
import curso1 from "../assets/curso1.jpg";
import curso2 from "../assets/curso2.jpg";
  
type Course = {
  title: string;
  studentName: string;
  hours: number;
  imagem: any;
  status: "concluido" | "andamento";
  certificateUrl?: string;
};

const mockCourses: Course[] = [
  {
    title: "Web Development Basics",
    studentName: "John Doe",
    hours: 40,
    status: "concluido",
    imagem: curso1,
    certificateUrl: "/certificates/web-development.pdf",
  },
  {
    title: "Advanced React",
    studentName: "John Doe",
    hours: 60,
    imagem: curso2,
    status: "andamento",
  },
  // ... outros cursos
];

const CourseList: React.FC = () => {
  return (
    <div className="listContainer">
      {mockCourses.map((course, index) => (
        <CourseCard key={index} {...course} />
      ))}
    </div>
  );
};

export default CourseList;
