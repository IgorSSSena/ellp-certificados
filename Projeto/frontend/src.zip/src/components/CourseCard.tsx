import React from "react";
import "../styles/course_card.css";

interface CourseCardProps {
  title: string;
  studentName: string;
  hours: number;
  status: "concluido" | "andamento";
  certificateUrl?: string;
  imagem: string;
}

const CourseCard: React.FC<CourseCardProps> = ({
  title,
  studentName,
  hours,
  status,
  certificateUrl,
  imagem,
}) => {
  const isCompleted = status === "concluido";

  return (
    <div className="custom-card">
      {/* Header com título */}
      <div className="card-header">
       
        <div className="card-icons">
          <span className="icon minimize"></span>
          <span className="icon close"></span>
        </div>
      </div>

      {/* Corpo do card */}
      <div className="card-body">
        <img src={imagem} alt={title} className="card-image" />

        <div className="card-info">
          <p>
            <strong>Duration:</strong> {hours} hours
          </p>
          <p>
            <strong>Status:</strong>{" "}
            {status === "concluido" ? "Completed" : "In Progress"}
          </p>

          {isCompleted && (
            <a href={certificateUrl} download className="download-button">
              Download Certificate
            </a>
          )}
        </div>
      </div>
    </div>
  );
};

export default CourseCard;
